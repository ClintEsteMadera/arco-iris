= Znn.com Benchmark System =
|
| Author:  Shang-Wen Cheng
| Date:    May 18-19, 2009
| History:
|  * [2009.05.18] Packaging version 0.1
|

''The contents of this README are under construction.''


== Benchmark requirements for self-adaptive techniques ==
''From paper submitted to SEAMS'09'' ([http://acme.able.cs.cmu.edu/pubs/show.php?id=291 paper])

 * Relevance to real-world problems and versatility to satisfy a wide range of research focus
 * Accessibility of system components and codebase that can be tested in a standalone environment
 * Capability to observe and change the system, by mechanisms that range from changing component parameters to altering overall system configuration
 * Metric for even-footing comparison, for example, CPUs have transistor count and MIPs, algorithms have duration in seconds over input size, and databases have throughput transactions per second
 * Allow changing the system dynamically
 * Support multiple quality dimensions (trade-off), e.g., availability, performance, reliability, security
 * Allow multiple adaptive operations, e.g., enabling or disabling servers, altering connections, tuning the fidelity of served content
 * Provide multiple alternatives to achieve a single operation, e.g., disabling a server by killing a process or powering down the machine, changing content fidelity by swapping configuration files or via an Apache plug-in
 * Provide multiple paths of system configuration to achieve the same goal, e.g., increasing overall throughput by adding servers followed by lowering fidelity, or in the reverse order, or by some completely different sequence of operations.


== System Software Prerequisites and Setup ==

Make sure your target node(s) has these software components installed; not all nodes require all components, so install according to the setup you need.  For example, you may only need Cygwin and Jakarta on your management node.  If you're trying to run all of these components on one machine, then you'll want to install all of these on that single machine node.

 * Management node:
   * On Windows: install Cygwin to get scripting capabilities
   * Jakarta JMeter 2.2
 * Znn.com server nodes
   * Apache 2.0.53
   * PHP 5.0.4 (Build date: Mar 31 2005 02:44:34)
     * An example PHPInfo output PDF has been included (Example-phpinfo.pdf)
   * Perl 5.8.0+ is fine
 * Znn.com database node
   * MySQL 4.1.11 for Win32 on ia32
     * MySQL database file provided, extracted from WICSA's wiki database
     * Dump for MySQL database included
     * SQL file for adding the user also included


== Znn.com Setup ==

The Znn.com target system consists of the servers and a set of mock news webpages.  So, once Apache and MySQL database servers are configured, the setup of Znn.com is relatively straightforward.

 1. Apache configuration files for Znn.com are in "system/effectors/fidelity.conf/", where
   * cygwin:  Cygwin-environment config files (actually also usable in Linux)
   * apache2.2:  Files for Linux and Apache 2.2-style configuration
 1. Check httpd.conf-f* (for Apache 2.2: apache2.conf-f*) to make sure that the ServerRoot path matches your Apache installation
 1. Copy/move the directory "znnpages" under system/ to the htdocs/ under your Apache installation or at a location of choice (on Linux, the Apache document root is usually at /var/www)
 1. Check the httpd.conf-f* (for Apache 2.2: znn.com-f*) to make sure DocumentRoot and the corresponding <Directory> paths match your installation

J/Meter: 

Rainbow: 


== Znn.com Benchmark Suite ==

This section describes the parts of the benchmark tool suite.  Probes, gauges, and effectors appear below.  The Apache configuration files and webpages for Znn.com are provided.  Also here are JMeter configuration files for generating the traffic profile of Slashdot effect.  Click [attachment:znn-benchmark-0.1.zip here] for the full ZIP archive.

Directory structure and table of contents of znn-benchmark/:

 * configfiles: configuration files for software component setup
   * jmeter: setup file for generating testing client request traffic
   * mysql: basic MySQL config file, copy or adapt your own to suit
   * php: basic PHP config file, copy or adapt your own to suit
 * script: Perl scripts to aid data extraction for analysis
   * (to come) Excel worksheet samples for data analysis
 * system: Znn.com system files
   * Probes (Perl script and a C program)
     * CPU load
     * Bandwidth
     * Disk I/O
     * Server content fidelity
     * ApacheTop 0.12.6 (C program, output modified for probing purposes)
   * Effectors (Perl scripts)
     * fidelity.conf: Apache configuration files used by changeFidelity.pl
       * HTTPD config files
       * Webpages
     * turnServer
     * changeFidelity
     * setRandomReject
 * rainbow: configuration files specific to the Rainbow framework, requires Rainbow library

Contents from the Rainbow library (to come):

 * Gauges (Java classes conforming to DASADA Gague API)
   * LoadGauge
   * LatencyGauge
   * DiskIOGauge
   * ApacheTopGauge
   * FidelityGauge
   * End2EndRespTimeGauge


== Points of Variability ==

