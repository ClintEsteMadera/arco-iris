#!/bin/sh

BIN_DIR=/cygdrive/c/server/rainbow/jakarta-jmeter-2.2/bin
DATA_DIR=c:/eclipse/data/rainbow/rainbow.znews.data
#BIN_DIR=/Users/zensoul/Documents/Application/jakarta-jmeter-2.2/bin
#DATA_DIR=/Users/zensoul/Documents/eclipse.data/rainbow-workspace/rainbow.znews.data
DATA_LABEL=0521c-local-control
PLAN_DIR=$DATA_DIR/plan
TEST_PLAN=RainbowZCase-explore.jmx

cd $BIN_DIR
java -jar ApacheJMeter.jar \
  -Ddata.path=$DATA_DIR -Ddata.label=$DATA_LABEL \
  -n -t $PLAN_DIR/$TEST_PLAN \
  | tee $DATA_DIR/$DATA_LABEL.log
