Extension:  Stitch scripts must have the extension ".s"; otherwise, the
Adaptation Manager will not know to load it.
