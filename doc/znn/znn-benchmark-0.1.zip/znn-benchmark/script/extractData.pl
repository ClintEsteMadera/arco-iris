#!/usr/bin/perl -Tw

########
# Overall function:  Take in a list of data files and output a processed set
# of data, tab separated, same number of files as the original (since each
# data set already exceeds half the allowable rows of data in Excel).
#
# Design:  Select only the relevant columns of the raw data, also normalizing
# the domain (start time) to start with zero.  Each data set is known to have
# eight columns.  We'll interpret the 6th (zero-based) column, which indicates
# whether request succeeded, and output a -1 response time if request failed.
########

use strict;
use IO::Handle;

my $IMG_SIZE = 209458;

for my $i (0..$#ARGV) {
  my $file = $ARGV[$i];
  my ($casestudy, $datelabel, $typelabel);
  if ($file =~ /(.+?-\d+)-(\w+)-(.+?)-/) {  # match file name components
    ($casestudy, $datelabel, $typelabel) = ($1, $2, $3);
  } else {
    next;
  }
  open(DIN, "<$file")
    || die "Cannot open file $file: $!";
  # prepare output file
  my $outfile = "$datelabel-$typelabel.txt";
  print("Reading $file, outputing $outfile...\n");
  open(DOUT, ">$outfile")
    || die "Cannot open output file $outfile: $!";
  # now process data
  my $firsttime;
  while (<DIN>) {
    chomp;
    s/Slow Start, /Slow Start /;  # replace original comma to avoid confusion
    my @items = split(/,\s*/);
    # only care about item 0, 1, 6 and 7
    my ($reqtime, $latency, $success, $bytes) =
      (int($items[0]), $items[1], $items[6], int($items[7]));
    # generate a new column that has the 0-normalized request time
    my $normtime = 0;
    if (defined($firsttime)) {
      $normtime = $reqtime - $firsttime;
    } else {  # grab the first point, and also print header
      $firsttime = $reqtime;
      print(DOUT "Req Time\tTimestamp\t$datelabel-$typelabel\t$datelabel-bytes\n");
    }
    # modify latency based on success flag
    if (lc($success) eq "false") {
      $latency = "-1";
    }
    # add image size to byte count, depending on the content type???
    $bytes += $IMG_SIZE;
    # output processed data
    printf(DOUT "%d\t%s\t%s\t%s\n", $normtime, $reqtime, $latency, $bytes);
    DOUT->flush();
  }
  close(DIN);
  close(DOUT);
}
