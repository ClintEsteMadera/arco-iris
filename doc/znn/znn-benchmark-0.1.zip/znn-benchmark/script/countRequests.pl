#!/usr/bin/perl -Tw

########
# Overall function:  Take in a list of data files and output a count of hits
# per time period, tab separated, same number of files as the original.
#
# Design:  Given a time period as input, convert to milliseconds, then count
# the number of hits per time period.
########

use strict;
use IO::Handle;

if ($#ARGV+1 < 2) {
  die "Need at least 2 args, first is time period in minutes, followed by files";
}

my $per = int($ARGV[0]) * 60 * 1000;  # 60*1000 ms per minute

for my $i (1..$#ARGV) {
  my $file = $ARGV[$i];
  my ($casestudy, $datelabel, $typelabel);
  if ($file =~ /(.+?-\d+)-(\w+)-(.+?)-/) {  # match file name components
    ($casestudy, $datelabel, $typelabel) = ($1, $2, $3);
  } else {
    next;
  }
  open(DIN, "<$file")
    || die "Cannot open file $file: $!";
  # prepare output file
  my $outfile = "$datelabel-hist.txt";
  print("Reading $file, counting to $outfile...\n");
  open(DOUT, ">$outfile")
    || die "Cannot open output file $outfile: $!";
  # now process data
  my ($firsttime, $period, $cnt, $lasttime);
  while (<DIN>) {
    chomp;
    s/Start, /Start /;  # replace original comma to avoid confusion
    my @items = split(/,\s*/);
    # only care about the time stamp, item 0
    my $reqtime = int($items[0]);
    # generate a new column that has the 0-normalized request time
    my $normtime = 0;
    if (defined($firsttime)) {
      $normtime = $reqtime - $firsttime;
      $lasttime = $normtime;
      # count
      if ($normtime < $period + $per) {
	++$cnt;
      } else {  # start new period
	# output processed data
	printf(DOUT "%d\t%d\n", $period, $cnt);
	DOUT->flush();
	# reset period and counter for next period
	$period += $per;
	$cnt = 1;  # count this one
      }
    } else {  # grab the first point, and also print header
      $firsttime = $reqtime;
      $period = $normtime;
      $cnt = 1;  # count this one
      print(DOUT "Start Period\tCount\n");
    }
  }
  printf(DOUT "%d\t%d\n", $lasttime, 0);
  close(DIN);
  close(DOUT);
}
