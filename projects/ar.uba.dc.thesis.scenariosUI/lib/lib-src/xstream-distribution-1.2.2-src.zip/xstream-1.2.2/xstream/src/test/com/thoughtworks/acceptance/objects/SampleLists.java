package com.thoughtworks.acceptance.objects;

import com.thoughtworks.acceptance.StandardObject;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class SampleLists extends StandardObject {
    public List good = new ArrayList();
    public Collection bad = new ArrayList();

}
