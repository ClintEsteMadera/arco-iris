package com.thoughtworks.xstream.converters.enums;

enum SimpleEnum {
    RED, GREEN, BLUE;
}
